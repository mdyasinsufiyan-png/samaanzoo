-- Samaanzo starter schema for Supabase
-- Run after the existing profiles and seller_applications tables.
-- This script creates products and orders, and adds safe RLS policies.
-- Admins are identified ONLY by auth.users.app_metadata.role = 'admin'.

create extension if not exists pgcrypto;

-- Keep existing seller_applications; add safe admin read/update policies if absent.
alter table public.seller_applications enable row level security;

drop policy if exists "Admin can view all seller applications" on public.seller_applications;
create policy "Admin can view all seller applications"
on public.seller_applications for select to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "Admin can update seller applications" on public.seller_applications;
create policy "Admin can update seller applications"
on public.seller_applications for update to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- Sellers can submit/update only their own application, but cannot set approved.
drop policy if exists "Seller can submit application" on public.seller_applications;
create policy "Seller can submit application"
on public.seller_applications for insert to authenticated
with check (auth.uid() = user_id and status = 'pending');

drop policy if exists "Seller can view own application" on public.seller_applications;
create policy "Seller can view own application"
on public.seller_applications for select to authenticated
using (auth.uid() = user_id);

drop policy if exists "Seller can update own pending application" on public.seller_applications;
create policy "Seller can update own pending application"
on public.seller_applications for update to authenticated
using (auth.uid() = user_id and status = 'pending')
with check (auth.uid() = user_id and status = 'pending');

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  category text not null default 'Other',
  description text,
  price numeric(12,2) not null check (price > 0),
  stock integer not null default 0 check (stock >= 0),
  image_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.products enable row level security;

drop policy if exists "Anyone can view active products" on public.products;
create policy "Anyone can view active products" on public.products
for select using (is_active = true or auth.uid() = seller_id or (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "Approved sellers can add products" on public.products;
create policy "Approved sellers can add products" on public.products
for insert to authenticated with check (
  auth.uid() = seller_id and exists (
    select 1 from public.seller_applications s
    where s.user_id = auth.uid() and s.status = 'approved'
  )
);

drop policy if exists "Sellers can update own products" on public.products;
create policy "Sellers can update own products" on public.products
for update to authenticated using (
  auth.uid() = seller_id and exists (
    select 1 from public.seller_applications s
    where s.user_id = auth.uid() and s.status = 'approved'
  )
) with check (auth.uid() = seller_id);

drop policy if exists "Admins can manage products" on public.products;
create policy "Admins can manage products" on public.products
for all to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references auth.users(id) on delete restrict,
  items jsonb not null,
  total numeric(12,2) not null check (total > 0),
  shipping_address text not null,
  phone text not null,
  payment_method text not null default 'cod' check (payment_method in ('cod')),
  payment_status text not null default 'pending' check (payment_status in ('pending','paid','failed','refunded')),
  status text not null default 'placed' check (status in ('placed','confirmed','shipped','delivered','cancelled')),
  created_at timestamptz not null default now()
);
alter table public.orders enable row level security;

drop policy if exists "Customers can create own orders" on public.orders;
create policy "Customers can create own orders" on public.orders
for insert to authenticated with check (auth.uid() = customer_id);

drop policy if exists "Customers can view own orders" on public.orders;
create policy "Customers can view own orders" on public.orders
for select to authenticated using (auth.uid() = customer_id);

drop policy if exists "Admins can view and update orders" on public.orders;
create policy "Admins can view and update orders" on public.orders
for all to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- Important: this starter uses COD only. Online payments require a trusted server/Edge
-- Function to create Razorpay orders and verify webhook signatures. Never put secret keys in HTML.
